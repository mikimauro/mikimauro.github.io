
import { GoogleGenAI, Type } from "@google/genai";
import { NewContactDraft } from "../types";

const cleanJsonResponse = (text: string | undefined): string => {
  if (!text) return "{}";
  let cleaned = text.replace(/```json/g, '').replace(/```/g, '').trim();
  const firstBrace = cleaned.indexOf('{');
  const lastBrace = cleaned.lastIndexOf('}');
  if (firstBrace !== -1 && lastBrace !== -1) {
    cleaned = cleaned.substring(firstBrace, lastBrace + 1);
  }
  return cleaned;
};

export const resizeImage = async (base64: string, maxSize: number = 1024): Promise<string> => {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const timeout = setTimeout(() => reject(new Error("Timeout caricamento")), 5000);
    img.onload = () => {
      clearTimeout(timeout);
      const canvas = document.createElement('canvas');
      let width = img.width;
      let height = img.height;
      if (width > height) {
        if (width > maxSize) { height *= maxSize / width; width = maxSize; }
      } else {
        if (height > maxSize) { width *= maxSize / height; height = maxSize; }
      }
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      if (!ctx) { resolve(base64); return; }
      ctx.drawImage(img, 0, 0, width, height);
      resolve(canvas.toDataURL('image/jpeg', 0.8).split(',')[1]);
    };
    img.onerror = () => reject(new Error("Errore immagine"));
    img.src = `data:image/jpeg;base64,${base64}`;
  });
};

export const extractContactFromImage = async (base64Image: string, mimeType: string): Promise<NewContactDraft> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    const resizedBase64 = await resizeImage(base64Image).catch(() => base64Image);
    
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: {
        parts: [
          { inlineData: { mimeType: 'image/jpeg', data: resizedBase64 } },
          { text: `Sei un sistema avanzato di data entry. Analizza questo biglietto (stampato o scritto a mano).
          ESTRAI CON PRECISIONE:
          - firstName, lastName: Nome e Cognome separati.
          - mobile: Cellulare (identificalo dal prefisso o icone).
          - phone: Telefono fisso.
          - whatsapp: Stesso numero mobile o specifico se indicato.
          - fax: Numero fax.
          - email: Indirizzo email completo.
          - company: Nome azienda/organizzazione.
          - vatNumber: Partita IVA (11 cifre).
          - fiscalCode: Codice Fiscale (16 caratteri).
          - address: Indirizzo completo.
          - notes: Trascrivi eventuali annotazioni scritte a mano a margine.
          
          Se un dato è scritto a mano, decifralo con cura. Restituisci SOLO un JSON valido.` }
        ]
      },
      config: {
        temperature: 0.1,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            firstName: { type: Type.STRING },
            lastName: { type: Type.STRING },
            company: { type: Type.STRING },
            jobTitle: { type: Type.STRING },
            mobile: { type: Type.STRING },
            phone: { type: Type.STRING },
            fax: { type: Type.STRING },
            email: { type: Type.STRING },
            website: { type: Type.STRING },
            address: { type: Type.STRING },
            vatNumber: { type: Type.STRING },
            fiscalCode: { type: Type.STRING },
            whatsapp: { type: Type.STRING },
            category: { type: Type.STRING },
            notes: { type: Type.STRING }
          }
        }
      }
    });

    const cleaned = cleanJsonResponse(response.text);
    return JSON.parse(cleaned);
  } catch (error) {
    console.error("Gemini Error:", error);
    return { firstName: "Nuovo", lastName: "Contatto", notes: "Errore durante l'analisi automatica." };
  }
};

export const extractTextFromImage = async (base64Image: string, mimeType: string): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    const resizedBase64 = await resizeImage(base64Image).catch(() => base64Image);
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: {
        parts: [
          { inlineData: { mimeType: 'image/jpeg', data: resizedBase64 } },
          { text: "Trascrivi integralmente tutto il testo visibile (anche se scritto a mano), mantenendo la formattazione originale e includendo numeri di telefono o codici fiscali." }
        ]
      }
    });
    return response.text || "";
  } catch (error) {
    return "Errore durante la trascrizione del testo.";
  }
};
