
import React, { useState, useRef, useEffect } from 'react';
import { extractContactFromImage, extractTextFromImage } from '../services/geminiService';
import { 
  Loader2, X, Check, Plus, Camera, AlertCircle, 
  Archive, Trash2, Save, RefreshCw
} from 'lucide-react';

interface ScannerProps {
  onScanComplete: (data: any, imageUrl: string, isDoc?: boolean) => void;
  onCancel: () => void;
  initialMode?: 'CARD' | 'TEXT';
}

const Scanner: React.FC<ScannerProps> = ({ onScanComplete, onCancel, initialMode = 'CARD' }) => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isCameraReady, setIsCameraReady] = useState(false);
  const [scanMode, setScanMode] = useState<'CARD' | 'TEXT'>(initialMode);
  
  // Gestione Multi-pagina e Risultati
  const [accumulatedText, setAccumulatedText] = useState<string>('');
  const [accumulatedImages, setAccumulatedImages] = useState<string[]>([]);
  const [scanResult, setScanResult] = useState<{data: any, url: string} | null>(null);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    startCamera();
    return () => stopCameraStream();
  }, []);

  const stopCameraStream = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setIsCameraReady(false);
  };

  const startCamera = async () => {
    setError(null);
    setIsCameraReady(false);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { 
          facingMode: 'environment', 
          width: { ideal: 1920 }, 
          height: { ideal: 1080 } 
        }
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.onloadedmetadata = () => {
          setIsCameraReady(true);
        };
      }
    } catch (err) {
      setError("Impossibile accedere alla fotocamera. Controlla i permessi.");
    }
  };

  const captureFrame = async () => {
    if (!isCameraReady || !videoRef.current || !canvasRef.current) return;
    
    setIsProcessing(true);
    setError(null);
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = videoRef.current.videoWidth;
    canvas.height = videoRef.current.videoHeight;
    ctx.drawImage(videoRef.current, 0, 0);
    
    const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
    const base64 = dataUrl.split(',')[1];

    try {
      stopCameraStream(); 
      
      let result;
      if (scanMode === 'TEXT') {
        result = await extractTextFromImage(base64, 'image/jpeg');
      } else {
        result = await extractContactFromImage(base64, 'image/jpeg');
      }
      
      setScanResult({ data: result, url: dataUrl });
    } catch (err) {
      console.error("Scanner Error:", err);
      setError("L'IA ha avuto un problema. Riprova lo scatto.");
      setScanResult({ data: scanMode === 'TEXT' ? "" : {}, url: dataUrl });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleAddPage = () => {
    if (!scanResult) return;
    const currentContent = typeof scanResult.data === 'string' ? scanResult.data : JSON.stringify(scanResult.data, null, 2);
    setAccumulatedText(prev => prev + (prev ? "\n\n--- PAGINA SUCCESSIVA ---\n\n" : "") + currentContent);
    setAccumulatedImages(prev => [...prev, scanResult.url]);
    setScanResult(null);
    startCamera();
  };

  const handleFinalize = (isArchived = false) => {
    if (!scanResult) return;
    
    if (scanMode === 'TEXT') {
      const finalContent = accumulatedText + (accumulatedText ? "\n\n--- PAGINA SUCCESSIVA ---\n\n" : "") + (typeof scanResult.data === 'string' ? scanResult.data : "");
      const finalImages = [...accumulatedImages, scanResult.url];
      onScanComplete({ content: finalContent, pages: finalImages, isArchived }, finalImages[0], true);
    } else {
      onScanComplete({ ...scanResult.data, isArchived }, scanResult.url, false);
    }
  };

  const handleDiscard = () => {
    setScanResult(null);
    startCamera();
  };

  return (
    <div className="fixed inset-0 bg-black z-[100] flex flex-col font-sans overflow-hidden">
      <canvas ref={canvasRef} className="hidden" />
      
      {/* Header Fissi */}
      <div className="absolute top-0 w-full p-6 flex justify-between items-center z-[110] bg-gradient-to-b from-black/80 via-black/40 to-transparent pt-safe">
        <div className="bg-white/10 backdrop-blur-xl px-4 py-2 rounded-full border border-white/20 flex items-center gap-3">
          <div className={`w-2 h-2 rounded-full ${isCameraReady ? 'bg-emerald-500 shadow-[0_0_10px_#10b981]' : 'bg-red-500 animate-pulse'}`}></div>
          <span className="text-white text-[10px] font-black uppercase tracking-widest">
            {scanMode === 'CARD' ? 'Business Card' : 'Document Scanner'}
          </span>
        </div>
        <button onClick={onCancel} className="bg-white/10 text-white p-3 rounded-full hover:bg-white/20 transition-colors backdrop-blur-xl">
          <X size={20} />
        </button>
      </div>

      {/* Area Contenuto: Fotocamera o Risultato */}
      <div className="flex-1 relative bg-black flex flex-col overflow-hidden">
        
        {/* Fotocamera Attiva */}
        {!scanResult && (
          <div className="w-full h-full relative flex items-center justify-center">
            <video 
              ref={videoRef} 
              autoPlay 
              playsInline 
              muted 
              className="w-full h-full object-cover" 
            />
            {/* Cornice di puntamento */}
            <div className={`absolute inset-10 border-2 ${scanMode === 'CARD' ? 'aspect-[1.6/1]' : 'aspect-[1/1.4]'} border-white/30 rounded-3xl pointer-events-none flex items-center justify-center`}>
              <div className="w-full h-full border border-white/10 rounded-3xl animate-pulse"></div>
            </div>
          </div>
        )}

        {/* Stato di Elaborazione AI */}
        {isProcessing && (
          <div className="absolute inset-0 z-[120] bg-black/90 backdrop-blur-3xl flex flex-col items-center justify-center text-white p-10 text-center">
            <div className="relative mb-8">
              <div className="w-24 h-24 border-4 border-primary/20 border-t-primary rounded-full animate-spin"></div>
              <Camera size={32} className="absolute inset-0 m-auto text-white animate-pulse" />
            </div>
            <h3 className="font-black uppercase tracking-tighter text-3xl mb-4">Elaborazione AI</h3>
            <p className="text-white/40 text-sm font-bold uppercase tracking-widest">Estrapolazione dati in corso...</p>
          </div>
        )}

        {/* RISULTATO E SOTTOMENU AZIONI (Scrollabile) */}
        {scanResult && !isProcessing && (
          <div className="absolute inset-0 z-[130] bg-gray-950 flex flex-col animate-in slide-in-from-bottom duration-500">
            <div className="flex-1 overflow-y-auto dark-scrollbar force-scrollbar p-6 pt-24 pb-48">
              <div className="max-w-md mx-auto space-y-8">
                <div className="relative group">
                  <img 
                    src={scanResult.url} 
                    className="w-full rounded-[2.5rem] shadow-[0_20px_60px_rgba(0,0,0,0.5)] border border-white/10" 
                    alt="Acquisizione" 
                  />
                  <div className="absolute -bottom-4 -right-4 bg-emerald-500 text-white p-4 rounded-2xl shadow-2xl border-4 border-gray-950">
                    <Check size={24} strokeWidth={4} />
                  </div>
                </div>

                <div className="bg-white/5 rounded-[2.5rem] p-8 border border-white/10 backdrop-blur-2xl">
                  <div className="flex items-center justify-between mb-6">
                    <p className="text-gray-500 text-[10px] font-black uppercase tracking-[0.3em]">Dati Rilevati</p>
                    {scanMode === 'TEXT' && accumulatedImages.length > 0 && (
                      <span className="bg-primary/20 text-primary text-[10px] font-black px-4 py-1.5 rounded-full uppercase">Pagine Totali: {accumulatedImages.length + 1}</span>
                    )}
                  </div>
                  
                  {scanMode === 'CARD' ? (
                    <div className="space-y-4">
                      <div>
                        <p className="text-white/40 text-[10px] uppercase font-black mb-1">Nome Completo</p>
                        <p className="text-white font-black text-2xl">{scanResult.data.firstName || '???'} {scanResult.data.lastName || ''}</p>
                      </div>
                      <div>
                        <p className="text-white/40 text-[10px] uppercase font-black mb-1">Azienda</p>
                        <p className="text-primary font-bold">{scanResult.data.company || 'N/D'}</p>
                      </div>
                    </div>
                  ) : (
                    <div>
                      <p className="text-white/40 text-[10px] uppercase font-black mb-3">Testo Estratto</p>
                      <p className="text-white/70 text-sm font-mono leading-relaxed whitespace-pre-wrap italic bg-black/30 p-4 rounded-xl">
                        {typeof scanResult.data === 'string' ? scanResult.data : 'Analisi completata.'}
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* BARRA AZIONI INFERIORE (SOTTOMENU) */}
            <div className="absolute bottom-0 w-full bg-white rounded-t-[3.5rem] p-8 pb-12 shadow-[0_-20px_80px_rgba(0,0,0,0.8)] z-[140]">
              <div className="max-w-md mx-auto">
                <div className="grid grid-cols-2 gap-4 mb-6">
                  {scanMode === 'TEXT' ? (
                    <button 
                      onClick={handleAddPage}
                      className="flex flex-col items-center justify-center p-5 bg-gray-100 rounded-[2.2rem] gap-2 active:scale-95 transition-all group"
                    >
                      <div className="w-12 h-12 bg-gray-900 text-white rounded-2xl flex items-center justify-center shadow-lg group-hover:bg-primary transition-colors"><Plus size={24}/></div>
                      <span className="text-[10px] font-black uppercase tracking-tighter">Agg. Pagina</span>
                    </button>
                  ) : (
                    <button 
                      onClick={() => handleFinalize(true)}
                      className="flex flex-col items-center justify-center p-5 bg-amber-50 rounded-[2.2rem] gap-2 active:scale-95 transition-all group text-amber-700"
                    >
                      <div className="w-12 h-12 bg-amber-500 text-white rounded-2xl flex items-center justify-center shadow-lg"><Archive size={24}/></div>
                      <span className="text-[10px] font-black uppercase tracking-tighter">Archivia</span>
                    </button>
                  )}
                  
                  <button 
                    onClick={handleDiscard}
                    className="flex flex-col items-center justify-center p-5 bg-red-50 rounded-[2.2rem] gap-2 active:scale-95 transition-all group text-red-600"
                  >
                    <div className="w-12 h-12 bg-red-500 text-white rounded-2xl flex items-center justify-center shadow-lg group-hover:bg-red-600 transition-colors"><Trash2 size={24}/></div>
                    <span className="text-[10px] font-black uppercase tracking-tighter">Scarta</span>
                  </button>
                </div>

                <button 
                  onClick={() => handleFinalize(false)}
                  className="w-full bg-primary text-white font-black py-6 rounded-[2.5rem] flex items-center justify-center gap-4 text-base uppercase shadow-2xl shadow-primary/40 active:scale-95 transition-all"
                >
                  <Save size={22} strokeWidth={3} />
                  {scanMode === 'CARD' ? 'Crea Contatto' : 'Salva Documento'}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* CONTROLLI FOTOCAMERA (Tasto Scatto e Switch) */}
      {!scanResult && !isProcessing && (
        <div className="bg-black p-8 pb-14 flex flex-col items-center gap-8 border-t border-white/5 relative z-[110] mb-safe">
          {/* Switch Modalità */}
          <div className="flex bg-white/5 p-1.5 rounded-2xl gap-1 w-full max-w-[280px] border border-white/10 backdrop-blur-lg">
            <button 
              onClick={() => setScanMode('CARD')} 
              className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${scanMode === 'CARD' ? 'bg-white text-black shadow-lg' : 'text-white/40'}`}
            >
              Card
            </button>
            <button 
              onClick={() => setScanMode('TEXT')} 
              className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${scanMode === 'TEXT' ? 'bg-white text-black shadow-lg' : 'text-white/40'}`}
            >
              Testo
            </button>
          </div>

          {/* Tasto Scatto Principale */}
          <div className="flex items-center justify-center">
            <button 
              onClick={captureFrame} 
              disabled={!isCameraReady}
              className="relative w-24 h-24 rounded-full border-4 border-white/30 flex items-center justify-center active:scale-90 transition-all p-2 bg-white/10 group disabled:opacity-30"
            >
              <div className="w-full h-full bg-white rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(255,255,255,0.4)] group-active:scale-95 transition-transform">
                {!isCameraReady ? <RefreshCw className="animate-spin text-black" size={24} /> : <div className="w-16 h-16 border-2 border-black/10 rounded-full"></div>}
              </div>
            </button>
          </div>
          
          <p className="text-white/30 text-[9px] font-black uppercase tracking-[0.4em] animate-pulse">Inquadra e Scatta</p>
        </div>
      )}

      {/* Notifica Errori */}
      {error && !scanResult && (
        <div className="absolute bottom-44 left-6 right-6 bg-red-600 text-white p-5 rounded-[2rem] flex items-center gap-4 animate-in fade-in slide-in-from-bottom-4 shadow-2xl z-[150] border-2 border-white/20">
          <div className="bg-white/20 p-2 rounded-full"><AlertCircle size={24} /></div>
          <p className="text-xs font-bold leading-tight">{error}</p>
        </div>
      )}
    </div>
  );
};

export default Scanner;
