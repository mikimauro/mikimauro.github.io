
import React, { useState, useMemo } from 'react';
import { Contact } from '../types';
import { Search, Plus, ScanLine, Phone, ChevronRight, MessageCircle, Heart, Archive, FileText, X } from 'lucide-react';

interface ContactListProps {
  contacts: Contact[];
  onSelectContact: (contact: Contact) => void;
  onAddNew: () => void;
  onScan: () => void;
  onOpenScanMenu: (mode: 'CARD' | 'TEXT' | 'DOC_LIST') => void;
}

const ContactList: React.FC<ContactListProps> = ({ contacts, onSelectContact, onAddNew, onScan, onOpenScanMenu }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [showArchived, setShowArchived] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const filteredContacts = useMemo(() => {
    return contacts.filter(c => {
      const matchesSearch = searchTerm === '' || 
        c.firstName.toLowerCase().includes(searchTerm.toLowerCase()) || 
        c.lastName.toLowerCase().includes(searchTerm.toLowerCase()) || 
        c.company?.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesArchive = showArchived ? c.isArchived : !c.isArchived;
      
      return matchesSearch && matchesArchive;
    });
  }, [contacts, searchTerm, showArchived]);

  const favorites = useMemo(() => filteredContacts.filter(c => c.isFavorite), [filteredContacts]);

  const groupedContacts = useMemo(() => {
    const groups: { [key: string]: Contact[] } = {};
    filteredContacts
      .filter(c => !c.isFavorite || searchTerm !== '')
      .sort((a, b) => a.firstName.localeCompare(b.firstName))
      .forEach(contact => {
        const firstLetter = contact.firstName.charAt(0).toUpperCase();
        if (!groups[firstLetter]) groups[firstLetter] = [];
        groups[firstLetter].push(contact);
      });
    return groups;
  }, [filteredContacts, searchTerm]);

  const handleQuickAction = (e: React.MouseEvent, href: string) => {
    e.stopPropagation();
    window.location.href = href;
  };

  return (
    <div className="flex flex-col h-full bg-white relative">
      {/* Overlay Menu Scansione */}
      {isMenuOpen && (
        <div className="absolute inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-end justify-center p-6" onClick={() => setIsMenuOpen(false)}>
          <div className="w-full bg-white rounded-[3rem] p-6 shadow-2xl animate-in slide-in-from-bottom duration-300" onClick={e => e.stopPropagation()}>
            <div className="flex justify-between items-center mb-6 px-2">
              <h3 className="font-black text-gray-900 uppercase tracking-tighter">Cosa vuoi fare?</h3>
              <button onClick={() => setIsMenuOpen(false)} className="p-2 bg-gray-100 rounded-full"><X size={20}/></button>
            </div>
            <div className="space-y-3">
              <button 
                onClick={() => { onOpenScanMenu('CARD'); setIsMenuOpen(false); }}
                className="w-full flex items-center gap-4 p-5 bg-primary/5 hover:bg-primary/10 rounded-[2rem] transition-all group"
              >
                <div className="w-12 h-12 bg-primary text-white rounded-2xl flex items-center justify-center shadow-lg shadow-primary/20 group-active:scale-90 transition-transform"><ScanLine size={24}/></div>
                <div className="text-left">
                  <p className="font-black text-gray-900 uppercase text-sm">Leggi Biglietto</p>
                  <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">Estrai contatti rubrica</p>
                </div>
              </button>
              <button 
                onClick={() => { onOpenScanMenu('TEXT'); setIsMenuOpen(false); }}
                className="w-full flex items-center gap-4 p-5 bg-gray-50 hover:bg-gray-100 rounded-[2rem] transition-all group"
              >
                <div className="w-12 h-12 bg-gray-900 text-white rounded-2xl flex items-center justify-center shadow-lg group-active:scale-90 transition-transform"><FileText size={24}/></div>
                <div className="text-left">
                  <p className="font-black text-gray-900 uppercase text-sm">Scansiona Documento</p>
                  <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">Trascrizione AI e PDF</p>
                </div>
              </button>
              <button 
                onClick={() => { onOpenScanMenu('DOC_LIST'); setIsMenuOpen(false); }}
                className="w-full flex items-center gap-4 p-5 bg-amber-50 hover:bg-amber-100 rounded-[2rem] transition-all group"
              >
                <div className="w-12 h-12 bg-amber-500 text-white rounded-2xl flex items-center justify-center shadow-lg shadow-amber-200 group-active:scale-90 transition-transform"><Archive size={24}/></div>
                <div className="text-left">
                  <p className="font-black text-gray-900 uppercase text-sm">Archivio Documenti</p>
                  <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">Vedi scansioni salvate</p>
                </div>
              </button>
            </div>
            <p className="text-center mt-6 text-[10px] text-gray-300 font-black uppercase tracking-widest">ScanBiz AI Engine v2.0</p>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="px-6 pt-8 pb-4">
        <div className="flex justify-between items-end mb-6">
          <div>
            <h1 className="text-3xl font-black text-gray-900 tracking-tight">
              {showArchived ? 'Archivio' : 'Rubrica'}
            </h1>
            <p className="text-gray-400 text-sm font-medium">
              {filteredContacts.length} contatti {showArchived ? 'archiviati' : 'salvati'}
            </p>
          </div>
          <div className="flex gap-2">
             <button 
               onClick={() => setShowArchived(!showArchived)} 
               className={`w-12 h-12 flex items-center justify-center rounded-2xl transition-all active:scale-90 ${showArchived ? 'bg-amber-100 text-amber-600' : 'bg-gray-100 text-gray-400'}`}
             >
               <Archive size={20} fill={showArchived ? "currentColor" : "none"} />
             </button>
             <button 
               onClick={() => setIsMenuOpen(true)} 
               className="w-12 h-12 flex items-center justify-center bg-gray-900 text-white rounded-2xl hover:bg-black transition-all active:scale-90 shadow-xl"
             >
               <ScanLine size={24} />
             </button>
             <button 
               onClick={onAddNew} 
               className="w-12 h-12 flex items-center justify-center bg-primary text-white rounded-2xl shadow-lg shadow-primary/30 hover:bg-blue-700 transition-all active:scale-90"
             >
               <Plus size={28} />
             </button>
          </div>
        </div>
        
        <div className="relative group">
          <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none text-gray-400 group-focus-within:text-primary transition-colors">
            <Search size={18} />
          </div>
          <input
            type="text"
            placeholder="Cerca nome o azienda..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-gray-100 border-none rounded-2xl py-4 pl-12 pr-4 text-gray-800 placeholder-gray-400 focus:ring-2 focus:ring-primary/20 focus:bg-white transition-all outline-none"
          />
        </div>
      </div>

      {/* List Content */}
      <div className="flex-1 overflow-y-auto px-6">
        {!showArchived && favorites.length > 0 && searchTerm === '' && (
          <div className="mb-8">
            <div className="flex items-center gap-2 mb-4 ml-2">
              <Heart size={14} className="text-rose-500" fill="currentColor" />
              <h3 className="text-rose-500 font-black text-xs uppercase tracking-widest">Preferiti</h3>
            </div>
            <div className="space-y-2">
              {favorites.map(contact => (
                <ContactItem key={contact.id} contact={contact} onSelect={onSelectContact} onAction={handleQuickAction} />
              ))}
            </div>
          </div>
        )}

        {Object.keys(groupedContacts).length === 0 && favorites.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center py-20">
            <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mb-4">
                <Search size={32} className="text-gray-300" />
            </div>
            <p className="text-gray-400 font-bold uppercase tracking-widest text-[10px]">Nessun risultato</p>
          </div>
        ) : (
          <div className="pb-32">
            {Object.keys(groupedContacts).sort().map(letter => (
              <div key={letter} className="mb-6">
                <h3 className="text-primary font-black text-sm mb-3 ml-2">{letter}</h3>
                <div className="space-y-2">
                  {groupedContacts[letter].map(contact => (
                    <ContactItem key={contact.id} contact={contact} onSelect={onSelectContact} onAction={handleQuickAction} />
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

interface ContactItemProps {
  contact: Contact;
  onSelect: (contact: Contact) => void;
  onAction: (e: React.MouseEvent, href: string) => void;
}

const ContactItem: React.FC<ContactItemProps> = ({ contact, onSelect, onAction }) => (
  <div 
    onClick={() => onSelect(contact)}
    className="bg-white p-3 rounded-2xl flex items-center gap-4 active:bg-gray-50 transition-colors border border-transparent hover:border-gray-100 shadow-sm"
  >
    <div className="w-14 h-14 bg-gradient-to-br from-gray-50 to-gray-100 rounded-2xl flex items-center justify-center text-gray-900 font-black text-xl border border-gray-100 relative">
      {contact.firstName.charAt(0)}{contact.lastName.charAt(0)}
      {contact.isFavorite && (
        <div className="absolute -top-1 -right-1 bg-rose-500 w-3 h-3 rounded-full border-2 border-white"></div>
      )}
    </div>
    
    <div className="flex-1 min-w-0">
      <h4 className="font-bold text-gray-900 truncate text-base">
        {contact.firstName} {contact.lastName}
      </h4>
      <p className="text-xs text-gray-400 truncate font-medium">
        {contact.company || 'Privato'}
      </p>
    </div>
    
    <div className="flex items-center gap-1">
      {contact.mobile && (
        <>
          <button 
            onClick={(e) => onAction(e, `tel:${contact.mobile}`)}
            className="p-3 text-emerald-500 hover:bg-emerald-50 rounded-xl transition-colors"
          >
            <Phone size={20} />
          </button>
          <button 
            onClick={(e) => onAction(e, `https://wa.me/${contact.mobile?.replace(/\D/g,'')}`)}
            className="p-3 text-green-600 hover:bg-green-50 rounded-xl transition-colors"
          >
            <MessageCircle size={20} />
          </button>
        </>
      )}
      <ChevronRight size={18} className="text-gray-300 ml-1" />
    </div>
  </div>
);

export default ContactList;
