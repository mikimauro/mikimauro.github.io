import React from 'react';
import { Contact } from '../types';
import { 
  ArrowLeft, 
  Edit2, 
  Phone, 
  MessageSquare, 
  Mail, 
  Globe, 
  Printer, 
  MapPin, 
  Trash2, 
  Tag, 
  CreditCard, 
  HeartPulse, 
  Briefcase, 
  FileText,
  Copy,
  Heart,
  Archive,
  AtSign
} from 'lucide-react';

interface ContactDetailsProps {
  contact: Contact;
  onBack: () => void;
  onEdit: () => void;
  onDelete: () => void;
  onToggleFavorite: () => void;
  onToggleArchive: () => void;
}

const WhatsAppIcon = ({ size = 24, className = "" }: { size?: number, className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" width={size} height={size} viewBox="0 0 24 24" fill="currentColor" className={className} stroke="none">
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.008-.57-.008-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.304-5.266 9.874 9.874 0 019.884-9.888 9.882 9.882 0 019.885 9.889 9.88 0 01-9.888 9.888" />
  </svg>
);

const ContactDetails: React.FC<ContactDetailsProps> = ({ contact, onBack, onEdit, onDelete, onToggleFavorite, onToggleArchive }) => {
  const handleCopy = (text: string) => navigator.clipboard.writeText(text);

  const getWhatsAppUrl = () => {
    const num = contact.whatsapp || contact.mobile;
    if (!num) return null;
    
    // Pulisce il numero mantenendo solo i digit
    let cleanNum = num.replace(/\D/g, '');
    
    // Gestione prefisso internazionale predefinito (+39 se manca e sembra un cellulare italiano)
    if (cleanNum.length === 10 && (cleanNum.startsWith('3'))) {
      cleanNum = '39' + cleanNum;
    } else if (cleanNum.startsWith('00')) {
      cleanNum = cleanNum.substring(2);
    }
    
    return `https://wa.me/${cleanNum}`;
  };

  const ActionButton = ({ href, icon: Icon, label, colorClass = "bg-gray-100 text-gray-700", shadowClass = "" }: any) => {
    const isDisabled = !href;
    if (isDisabled) {
      return (
        <div className="flex flex-col items-center justify-center p-4 rounded-[2.2rem] gap-2 opacity-15 grayscale cursor-not-allowed bg-gray-100 border border-gray-200">
          <Icon size={26} />
          <span className="text-[9px] font-black uppercase tracking-tighter">{label}</span>
        </div>
      );
    }
    return (
      <a 
        href={href} 
        target="_blank" 
        rel="noopener noreferrer" 
        className={`flex flex-col items-center justify-center p-4 rounded-[2.2rem] gap-2 transition-all active:scale-95 shadow-xl hover:-translate-y-1 ${shadowClass} ${colorClass}`}
      >
        <Icon size={26} className="drop-shadow-md" />
        <span className="text-[9px] font-black uppercase tracking-tighter">{label}</span>
      </a>
    );
  };

  const DetailRow = ({ icon: Icon, label, value, iconColorClass = "text-gray-500", isLink = false, href = "", extraIcon: ExtraIcon = null }: any) => {
    if (!value) return null;
    return (
      <div className="flex items-start gap-4 py-4 border-b border-gray-100 last:border-0 group">
        <div className={`mt-0.5 p-2.5 bg-gray-50 rounded-xl ${iconColorClass} transition-colors group-hover:bg-white group-hover:shadow-sm`}><Icon size={18} /></div>
        <div className="flex-1 overflow-hidden">
          <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mb-0.5">{label}</p>
          <div className="flex items-center gap-2">
            {isLink ? (
              <a href={href} className="text-primary font-bold break-words hover:underline flex items-center gap-1.5">
                {ExtraIcon && <ExtraIcon size={14} className="flex-shrink-0" />}
                {value}
              </a>
            ) : (
              <p className="text-gray-900 font-medium break-words flex items-center gap-1.5">
                {ExtraIcon && <ExtraIcon size={14} className="flex-shrink-0" />}
                {value}
              </p>
            )}
          </div>
        </div>
        <button onClick={() => handleCopy(value)} className="p-2 text-gray-300 hover:text-primary opacity-0 group-hover:opacity-100 transition-all"><Copy size={14} /></button>
      </div>
    );
  };

  const CategoryIcon = (() => {
    switch(contact.category) {
      case 'Lavoro': return Briefcase;
      case 'Sanità': return HeartPulse;
      case 'Banca': return CreditCard;
      case 'Documenti': return FileText;
      default: return Tag;
    }
  })();

  return (
    <div className="flex flex-col h-full bg-white font-sans">
      <div className="sticky top-0 bg-white/95 backdrop-blur-xl z-20 px-4 py-3 flex items-center justify-between border-b border-gray-100">
        <button onClick={onBack} className="p-2 -ml-2 text-gray-600 hover:bg-gray-100 rounded-full transition-colors"><ArrowLeft size={24} /></button>
        <div className="flex gap-1">
           <button 
             onClick={onToggleFavorite} 
             className={`p-2.5 rounded-full transition-colors ${contact.isFavorite ? 'text-rose-500 bg-rose-50' : 'text-gray-400 hover:bg-gray-100'}`}
           >
             <Heart size={20} fill={contact.isFavorite ? "currentColor" : "none"} />
           </button>
           <button 
             onClick={onToggleArchive} 
             className={`p-2.5 rounded-full transition-colors ${contact.isArchived ? 'text-amber-600 bg-amber-50' : 'text-gray-400 hover:bg-gray-100'}`}
           >
             <Archive size={20} fill={contact.isArchived ? "currentColor" : "none"} />
           </button>
           <button onClick={onDelete} className="p-2.5 text-red-500 hover:bg-red-50 rounded-full transition-colors"><Trash2 size={20} /></button>
           <button onClick={onEdit} className="p-2.5 text-primary hover:bg-blue-50 rounded-full transition-colors"><Edit2 size={20} /></button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto pb-24">
        <div className="flex flex-col items-center pt-10 pb-8 px-4 bg-gradient-to-b from-white via-gray-50/30 to-white">
          <div className="w-28 h-28 bg-gradient-to-tr from-primary via-blue-500 to-indigo-600 rounded-[2.8rem] flex items-center justify-center text-white text-4xl font-black mb-5 shadow-2xl shadow-blue-200/50 rotate-2 relative">
            <span className="-rotate-2">{contact.firstName.charAt(0)}{contact.lastName.charAt(0)}</span>
            {contact.isFavorite && (
              <div className="absolute -top-2 -right-2 bg-rose-500 text-white p-1.5 rounded-full shadow-lg border-2 border-white">
                <Heart size={14} fill="currentColor" />
              </div>
            )}
          </div>
          <h2 className="text-2xl font-black text-gray-900 text-center leading-tight">
            {contact.firstName} {contact.lastName}
            {contact.isArchived && <span className="ml-2 text-[10px] bg-amber-100 text-amber-700 px-2 py-0.5 rounded uppercase align-middle">Archiviato</span>}
          </h2>
          <div className="flex flex-wrap justify-center items-center gap-2 mt-3">
            {contact.jobTitle && <span className="text-gray-500 font-bold text-sm">{contact.jobTitle}</span>}
            {contact.category && <span className="flex items-center gap-1.5 bg-gray-900 text-white px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest shadow-lg shadow-gray-200"><CategoryIcon size={12} strokeWidth={3} />{contact.category}</span>}
          </div>
          {contact.company && <p className="text-gray-400 text-xs font-bold mt-2 uppercase tracking-wide">{contact.company}</p>}
        </div>

        <div className="grid grid-cols-4 gap-3 px-6 mb-10">
          <ActionButton 
            href={contact.mobile || contact.phone ? `tel:${contact.mobile || contact.phone}` : null} 
            icon={Phone} 
            label="Chiama" 
            colorClass="bg-gradient-to-br from-emerald-400 to-emerald-600 text-white" 
            shadowClass="shadow-emerald-200" 
          />
          <ActionButton 
            href={contact.mobile ? `sms:${contact.mobile}` : null} 
            icon={MessageSquare} 
            label="SMS" 
            colorClass="bg-gradient-to-br from-sky-400 to-sky-600 text-white" 
            shadowClass="shadow-sky-200" 
          />
          <ActionButton 
            href={getWhatsAppUrl()} 
            icon={WhatsAppIcon} 
            label="WhatsApp" 
            colorClass="bg-gradient-to-br from-green-500 to-green-700 text-white" 
            shadowClass="shadow-green-300" 
          />
          <ActionButton 
            href={contact.email ? `mailto:${contact.email}` : null} 
            icon={AtSign} 
            label="Email" 
            colorClass="bg-gradient-to-br from-rose-400 to-rose-600 text-white" 
            shadowClass="shadow-rose-200" 
          />
        </div>

        <div className="px-6 py-8 bg-white rounded-t-[3.5rem] shadow-[0_-25px_60px_rgba(0,0,0,0.06)] border-t border-gray-50 min-h-[50vh]">
          <div className="mb-8">
            <h4 className="text-[11px] font-black text-gray-300 uppercase tracking-[0.25em] mb-4 pl-1">Contatti Diretti</h4>
            <DetailRow icon={Phone} label="Cellulare" value={contact.mobile} iconColorClass="text-emerald-500" isLink href={`tel:${contact.mobile}`} />
            <DetailRow icon={Phone} label="Telefono Fisso" value={contact.phone} iconColorClass="text-gray-400" isLink href={`tel:${contact.phone}`} />
            <DetailRow 
              icon={WhatsAppIcon} 
              label="WhatsApp" 
              value={contact.whatsapp || contact.mobile} 
              iconColorClass="text-green-600" 
              isLink 
              href={getWhatsAppUrl() || '#'} 
              extraIcon={WhatsAppIcon}
            />
            <DetailRow icon={AtSign} label="Email" value={contact.email} iconColorClass="text-rose-500" isLink href={`mailto:${contact.email}`} />
          </div>
          <div className="mb-8">
            <h4 className="text-[11px] font-black text-gray-300 uppercase tracking-[0.25em] mb-4 pl-1">Info Professionali</h4>
            <DetailRow icon={Globe} label="Sito Web" value={contact.website} iconColorClass="text-blue-500" isLink href={contact.website?.startsWith('http') ? contact.website : `https://${contact.website}`} />
            <DetailRow icon={MapPin} label="Indirizzo" value={contact.address} iconColorClass="text-orange-400" />
            <DetailRow icon={Printer} label="Fax" value={contact.fax} iconColorClass="text-gray-400" />
          </div>
          <div className="mb-8">
            <h4 className="text-[11px] font-black text-gray-300 uppercase tracking-[0.25em] mb-4 pl-1">Dati Fiscali</h4>
            <DetailRow icon={FileText} label="P. IVA" value={contact.vatNumber} iconColorClass="text-indigo-400" />
            <DetailRow icon={FileText} label="Codice Fiscale" value={contact.fiscalCode} iconColorClass="text-purple-400" />
          </div>
          {contact.notes && (
            <div className="mt-8 p-6 bg-gray-50 rounded-[2.5rem] border border-gray-100">
               <div className="flex items-center gap-2 mb-4"><FileText size={16} className="text-gray-400" /><p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Note & Dati Scanner</p></div>
               <p className="text-gray-700 text-sm whitespace-pre-wrap font-mono leading-relaxed bg-white p-4 rounded-2xl border border-gray-100/50 shadow-sm">{contact.notes}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ContactDetails;