import React, { useState } from 'react';
import { ScannedDocument } from '../types';
import { Save, X, FileText, Download, Trash2, Loader2, FileDown } from 'lucide-react';

interface DocumentEditorProps {
  initialData: Partial<ScannedDocument>;
  onSave: (doc: ScannedDocument) => void;
  onCancel: () => void;
  onDelete?: () => void;
}

const DocumentEditor: React.FC<DocumentEditorProps> = ({ initialData, onSave, onCancel, onDelete }) => {
  const [title, setTitle] = useState(initialData.title || '');
  const [content, setContent] = useState(initialData.content || '');
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false);

  const handleSave = () => {
    onSave({
      id: initialData.id || crypto.randomUUID(),
      title: title || 'Documento senza titolo',
      content,
      pages: initialData.pages || [],
      createdAt: initialData.createdAt || Date.now()
    });
  };

  const handleDownloadTxt = () => {
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${title.replace(/\s+/g, '_') || 'documento'}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleGeneratePDF = async () => {
    setIsGeneratingPDF(true);
    try {
      const { jsPDF } = await import('jspdf');
      const doc = new jsPDF();
      const pageWidth = doc.internal.pageSize.getWidth();
      const pageHeight = doc.internal.pageSize.getHeight();
      const margin = 20;
      const contentWidth = pageWidth - (2 * margin);

      // --- PAGINA 1: TESTO ---
      doc.setFont("helvetica", "bold");
      doc.setFontSize(22);
      doc.text(title || 'Documento senza titolo', margin, 30);
      
      doc.setFont("helvetica", "normal");
      doc.setFontSize(10);
      doc.setTextColor(120);
      doc.text(`Esportato da ScanBiz il: ${new Date().toLocaleDateString()} ${new Date().toLocaleTimeString()}`, margin, 40);
      
      doc.setDrawColor(230);
      doc.line(margin, 45, pageWidth - margin, 45);

      doc.setTextColor(40);
      doc.setFontSize(11);
      const splitText = doc.splitTextToSize(content, contentWidth);
      
      let y = 55;
      const lineHeight = 7;

      for (const line of splitText) {
        if (y > pageHeight - margin) {
          doc.addPage();
          y = margin;
        }
        doc.text(line, margin, y);
        y += lineHeight;
      }

      // --- PAGINE SUCCESSIVE: SCANSIONI ORIGINALI ---
      if (initialData.pages && initialData.pages.length > 0) {
        for (const pageUrl of initialData.pages) {
          doc.addPage();
          try {
            // Aggiungiamo l'immagine adattandola alla pagina A4
            doc.addImage(pageUrl, 'JPEG', 0, 0, pageWidth, pageHeight, undefined, 'FAST');
          } catch (e) {
            console.error("Errore aggiunta immagine al PDF:", e);
          }
        }
      }

      doc.save(`${title.replace(/\s+/g, '_') || 'documento'}.pdf`);
    } catch (error) {
      console.error("Errore generazione PDF:", error);
      alert("Si è verificato un errore durante la generazione del PDF.");
    } finally {
      setIsGeneratingPDF(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-gray-50 font-sans">
      <div className="sticky top-0 bg-white border-b px-4 py-3 flex items-center justify-between z-20">
        <button onClick={onCancel} className="p-2 text-gray-500 hover:bg-gray-100 rounded-full transition-colors">
          <X size={24} />
        </button>
        <h2 className="font-black text-gray-900 uppercase tracking-tighter text-sm">Editor Documento</h2>
        <button onClick={handleSave} className="bg-primary text-white px-5 py-2 rounded-2xl font-bold text-sm flex items-center gap-2 shadow-lg shadow-primary/20 transition-all active:scale-95">
          <Save size={18} /> SALVA
        </button>
      </div>

      <div className="flex-1 p-5 overflow-y-auto space-y-5">
        <div className="bg-white rounded-[2.5rem] p-6 shadow-sm border border-gray-100">
          <label className="block text-[10px] font-black text-gray-300 uppercase tracking-[0.2em] mb-3 ml-1">Titolo Documento</label>
          <input 
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full text-xl font-black text-gray-900 focus:outline-none placeholder-gray-200 bg-transparent"
            placeholder="Es. Appunti Riunione..."
          />
        </div>

        <div className="bg-white rounded-[2.5rem] p-6 shadow-sm border border-gray-100 flex flex-col min-h-[400px]">
          <label className="block text-[10px] font-black text-gray-300 uppercase tracking-[0.2em] mb-4 ml-1">Testo Rilevato AI</label>
          <textarea 
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="w-full flex-1 text-gray-700 leading-relaxed font-mono text-sm focus:outline-none resize-none bg-transparent"
            placeholder="Il testo scansionato apparirà qui..."
          />
        </div>
      </div>

      <div className="p-6 bg-white border-t space-y-4">
        <div className="flex gap-3">
          <button 
            onClick={handleGeneratePDF} 
            disabled={isGeneratingPDF}
            className="flex-[2] bg-gray-900 text-white py-4 rounded-[2rem] font-bold flex items-center justify-center gap-2 shadow-xl hover:bg-black transition-all active:scale-95 disabled:opacity-50"
          >
            {isGeneratingPDF ? <Loader2 size={20} className="animate-spin" /> : <FileDown size={20} />}
            {isGeneratingPDF ? 'GENERAZIONE...' : 'ESPORTA PDF'}
          </button>
          <button 
            onClick={handleDownloadTxt} 
            className="flex-1 bg-gray-100 text-gray-600 py-4 rounded-[2rem] font-bold flex items-center justify-center gap-2 hover:bg-gray-200 transition-all active:scale-95"
          >
            <Download size={18} /> .TXT
          </button>
        </div>
        
        {onDelete && (
          <button 
            onClick={onDelete} 
            className="w-full py-3 text-red-400 hover:text-red-600 font-bold text-xs uppercase tracking-widest flex items-center justify-center gap-2 transition-colors"
          >
            <Trash2 size={14} /> Elimina Documento
          </button>
        )}
      </div>
    </div>
  );
};

export default DocumentEditor;