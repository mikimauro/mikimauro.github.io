import React, { useState } from 'react';
import { Contact, NewContactDraft } from '../types';
import { Save, X, User, Phone, Mail, MapPin, Building, FileText, Globe, Tag } from 'lucide-react';

interface ContactEditorProps {
  initialData: NewContactDraft | Contact;
  onSave: (contact: Contact | NewContactDraft) => void;
  onCancel: () => void;
  isNew: boolean;
}

const ContactEditor: React.FC<ContactEditorProps> = ({ initialData, onSave, onCancel, isNew }) => {
  const [formData, setFormData] = useState<NewContactDraft | Contact>(initialData);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  const InputGroup = ({ icon: Icon, label, name, type = "text", placeholder = "" }: any) => (
    <div className="mb-4">
      <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1 ml-1">{label}</label>
      <div className="relative">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <Icon size={18} className="text-gray-400" />
        </div>
        <input
          type={type}
          name={name}
          value={(formData as any)[name] || ''}
          onChange={handleChange}
          placeholder={placeholder}
          className="w-full pl-10 pr-3 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:bg-white transition-all text-sm"
        />
      </div>
    </div>
  );

  return (
    <div className="flex flex-col h-full bg-white">
      {/* Header */}
      <div className="sticky top-0 bg-white border-b z-10 px-4 py-3 flex items-center justify-between shadow-sm">
        <button onClick={onCancel} className="text-gray-500 hover:text-gray-800 p-2">
          <X size={24} />
        </button>
        <h1 className="text-lg font-bold text-gray-800">{isNew ? 'Nuovo Contatto' : 'Modifica Contatto'}</h1>
        <button 
          onClick={handleSubmit} 
          className="text-primary font-bold hover:text-blue-700 p-2 flex items-center gap-1"
        >
          <Save size={20} />
          <span>Salva</span>
        </button>
      </div>

      {/* Form Content */}
      <div className="flex-1 overflow-y-auto p-4 pb-24">
        <form onSubmit={handleSubmit} className="space-y-6">
          
          <div className="space-y-1">
             <h3 className="text-sm font-bold text-gray-900 border-b pb-2 mb-4">Informazioni Principali</h3>
             <InputGroup icon={User} label="Nome" name="firstName" placeholder="Nome" />
             <InputGroup icon={User} label="Cognome" name="lastName" placeholder="Cognome" />
             
             {/* Category Selector */}
             <div className="mb-4">
                <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1 ml-1">Categoria</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Tag size={18} className="text-gray-400" />
                  </div>
                  <select
                    name="category"
                    value={formData.category || 'Altro'}
                    onChange={handleChange}
                    className="w-full pl-10 pr-3 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:bg-white transition-all text-sm appearance-none"
                  >
                    <option value="Lavoro">Lavoro (Biglietto da Visita)</option>
                    <option value="Documenti">Documenti (Carta d'Identità)</option>
                    <option value="Sanità">Sanità (Tessera Sanitaria)</option>
                    <option value="Banca">Banca (Carte di Credito)</option>
                    <option value="Personale">Personale</option>
                    <option value="Altro">Altro</option>
                  </select>
                </div>
             </div>

             <InputGroup icon={Building} label="Azienda / Ente" name="company" placeholder="Nome Azienda o Emittente" />
             <InputGroup icon={User} label="Ruolo / Titolo" name="jobTitle" placeholder="es. Manager" />
          </div>

          <div className="space-y-1">
             <h3 className="text-sm font-bold text-gray-900 border-b pb-2 mb-4">Recapiti</h3>
             <InputGroup icon={Phone} label="Cellulare" name="mobile" type="tel" />
             <InputGroup icon={Phone} label="Telefono Fisso" name="phone" type="tel" />
             <InputGroup icon={Phone} label="WhatsApp" name="whatsapp" type="tel" placeholder="+39..." />
             <InputGroup icon={FileText} label="Fax" name="fax" type="tel" />
             <InputGroup icon={Mail} label="Email" name="email" type="email" />
             <InputGroup icon={Globe} label="Sito Web" name="website" type="url" />
          </div>

          <div className="space-y-1">
             <h3 className="text-sm font-bold text-gray-900 border-b pb-2 mb-4">Dettagli Aziendali / Fiscali</h3>
             <InputGroup icon={MapPin} label="Indirizzo / Residenza" name="address" />
             <InputGroup icon={FileText} label="P. IVA" name="vatNumber" />
             <InputGroup icon={FileText} label="Codice Fiscale" name="fiscalCode" />
          </div>

          <div className="space-y-1">
            <h3 className="text-sm font-bold text-gray-900 border-b pb-2 mb-4">Dati Documento & Note</h3>
            <textarea
              name="notes"
              value={formData.notes || ''}
              onChange={handleChange}
              rows={5}
              placeholder="Numeri documenti, scadenze, note aggiuntive..."
              className="w-full p-3 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:bg-white transition-all text-sm font-mono"
            />
          </div>

        </form>
      </div>
    </div>
  );
};

export default ContactEditor;